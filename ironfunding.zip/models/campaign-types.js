module.exports = [
  "Artisanal",
  "Bikes",
  "DIY",
  "Innovation",
  "Just for Kids",
  "Robots",
  "RPGs",
  "Sci-Fi and Fantasy",
  "Space",
  "STEM",
  "Virtual Reality"
];
